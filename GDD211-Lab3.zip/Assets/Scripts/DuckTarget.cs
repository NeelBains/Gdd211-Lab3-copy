﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DuckTarget : Target
{
    public override void hitTarget()
    {
        base.hitTarget();
    }

    private float movementSpeed = 3f;

    void Update()
    {
        //update the position
        transform.position = transform.position + new Vector3(movementSpeed * Time.deltaTime, 0, 0);

    }
}
